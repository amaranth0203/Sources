#include "Animal.h"
#include "Dog.h"
#include <stdio.h>
Dog::Dog( )
{
    species = "Dog" ;
    how_to_cry = "bowwow ~ bowwow ~ bowwow ~ " ;
    printf( "[+] %s borned\n" , species ) ;
}
void Dog::Cry( )
{
    printf( "[+] %s is crying : %s\n" , species , how_to_cry ) ;
}
char* Dog::getName( ) { return species ; }

