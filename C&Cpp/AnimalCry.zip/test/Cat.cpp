#include "Animal.h"
#include "Cat.h"
#include <stdio.h>
Cat::Cat( )
{
    species = "Cat" ;
    how_to_cry = "miaul  ~ miaul  ~ miaul  ~ " ;
    printf( "[+] %s borned\n" , species ) ;
}
void Cat::Cry( )
{
    printf( "[+] %s is crying : %s\n" , species , how_to_cry ) ;
}
char* Cat::getName( ) { return species ; }

