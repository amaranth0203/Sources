#ifndef Chick_H
#define Chick_H
#include "Animal.h"
class Chick : public Animal
{
public :
    Chick( ) ;
    void Cry( ) ;
    char* getName( ) ;
} ;
#endif

