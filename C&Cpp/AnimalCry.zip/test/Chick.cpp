#include "Animal.h"
#include "Chick.h"
#include <stdio.h>
Chick::Chick( )
{
    species = "Chick" ;
    how_to_cry = "bi ~ bi ~ bi ~ " ;
    printf( "[+] %s borned\n" , species ) ;
}
void Chick::Cry( )
{
    printf( "[+] %s is crying : %s\n" , species , how_to_cry ) ;
}
char* Chick::getName( ) { return species ; }

