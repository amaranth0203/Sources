#ifndef ANIMAL_H
#define ANIMAL_H
class Animal
{
protected :
    char *species ;
    char *how_to_cry ;
public :
    virtual char* getName( ) = 0 ;
    virtual void Cry( ) = 0 ;
} ;
#endif

