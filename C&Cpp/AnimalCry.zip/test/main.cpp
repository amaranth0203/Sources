#include "Animal.h"
#include "Chick.cpp"
#include "Cat.cpp"
#include "Dog.cpp"
#include "Fox.cpp"
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
void animalCry( Animal* tmp ) ;
void cls( ) ;
void tips( ) ;
void whattodo( Animal* tmp ) ;
void todoinside( Animal* tmp ) ;
int main( )
{
    // Chick Chick ;
    // Cat cat ;
    // Dog dog ;
    // Fox fox ;
    // animalCry( &Chick ) ;
    // animalCry( &cat ) ;
    // animalCry( &dog ) ;
    // animalCry( &fox ) ;
    // system( "pause>nul" ) ;
    int status ;
    Animal *tmp ;
    while( 1 )
    {
        cls( ) ;
        tips( ) ;
        status = getch( ) ;
        if( status == '0' )
        {
            puts( "[+] bye" ) ;
            break ;
        }
        switch( status )
        {
        case '1' :
            tmp = new Chick ;
            todoinside( tmp ) ;
            break ;
        case '2' :
            tmp = new Cat ;
            todoinside( tmp ) ;
            break ;
        case '3' :
            tmp = new Dog ;
            todoinside( tmp ) ;
            break ;
        case '4' :
            tmp = new Fox ;
            todoinside( tmp ) ;
            break ;
        }
    }
    system( "pause>nul" ) ;
    return 0 ;
}

void animalCry( Animal* tmp ) { tmp->Cry( ) ; }
void cls( ) 
{ 
    system( "cls" ) ; 
    puts( " ******************************************************************" ) ;
    puts( " ** Small testing for Encapsulation Inheritance & Polymorphism **" ) ;
    puts( " ******************************************************************" ) ;
}
void tips( )
{
    puts( "" ) ;
    puts( " * Which animal do you what to create ? " ) ;
    puts( " 1 . Chick " ) ;
    puts( " 2 . Cat " ) ;
    puts( " 3 . Dog " ) ;
    puts( " 4 . Fox " ) ;
    puts( " 0 . exit " ) ;
    puts( "" ) ;
}
void whattodo( Animal* tmp )
{
    puts( "" ) ;
    printf( " * Now you have a [ %s ] , what do you want to do ? \n" , tmp->getName( ) ) ;
    puts( " 1 . Make it cry " ) ;
    puts( " 2 . Create another animal " ) ;
    puts( " 0 . Return to Previous menu " ) ;
    puts( "" ) ;
}
void todoinside( Animal* tmp )
{
    int status ;
    while( 1 )
    {
        if( status == '2' || status == '0' ) return ;
        else if( status == '1' )
        {
            cls( ) ;
            printf( "\n\t" ) ;
            tmp->Cry( ) ;
            whattodo( tmp ) ;
            status = getch( ) ;
        }
        else
        {
            cls( ) ;
            whattodo( tmp ) ;
            status = getch( ) ;
        }
    }
}

