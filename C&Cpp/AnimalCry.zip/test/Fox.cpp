#include "Animal.h"
#include "Fox.h"
#include <stdio.h>
Fox::Fox( )
{
    species = "Fox" ;
    how_to_cry = "T_T What does the fox say ?! " ;
    printf( "[+] %s borned\n" , species ) ;
}
void Fox::Cry( )
{
    printf( "[+] %s is crying : %s\n" , species , how_to_cry ) ;
}
char* Fox::getName( ) { return species ; }

