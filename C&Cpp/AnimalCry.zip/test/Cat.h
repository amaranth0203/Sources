#ifndef CAT_H
#define CAT_H
#include "Animal.h"
class Cat : public Animal
{
public :
    Cat( ) ;
    void Cry( ) ;
    char* getName( ) ;
} ;
#endif

