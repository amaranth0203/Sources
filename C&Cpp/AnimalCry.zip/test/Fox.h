#ifndef Fox_H
#define Fox_H
#include "Animal.h"
class Fox : public Animal
{
public :
    Fox( ) ;
    void Cry( ) ;
    char* getName( ) ;
} ;
#endif

