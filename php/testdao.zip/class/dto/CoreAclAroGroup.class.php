<?php
	/**
	 * Object represents table 'core_acl_aro_groups'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class CoreAclAroGroup{
		
		var $groupId;
		var $parentId;
		var $name;
		var $lft;
		var $rgt;
		
	}
?>