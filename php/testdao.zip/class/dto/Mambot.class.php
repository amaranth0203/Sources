<?php
	/**
	 * Object represents table 'mambots'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Mambot{
		
		var $id;
		var $name;
		var $element;
		var $folder;
		var $acces;
		var $ordering;
		var $published;
		var $iscore;
		var $clientId;
		var $checkedOut;
		var $checkedOutTime;
		var $param;
		
	}
?>