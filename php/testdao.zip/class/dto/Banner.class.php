<?php
	/**
	 * Object represents table 'banner'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Banner{
		
		var $bid;
		var $cid;
		var $type;
		var $name;
		var $imptotal;
		var $impmade;
		var $click;
		var $imageurl;
		var $clickurl;
		var $date;
		var $showBanner;
		var $checkedOut;
		var $checkedOutTime;
		var $editor;
		var $custombannercode;
		
	}
?>