<?php
	/**
	 * Object represents table 'templates_menu'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class TemplatesMenu{
		
		var $template;
		var $menuid;
		var $clientId;
		
	}
?>