<?php
	/**
	 * Object represents table 'contact_details'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class ContactDetail{
		
		var $id;
		var $name;
		var $conPosition;
		var $addres;
		var $suburb;
		var $state;
		var $country;
		var $postcode;
		var $telephone;
		var $fax;
		var $misc;
		var $image;
		var $imagepo;
		var $emailTo;
		var $defaultCon;
		var $published;
		var $checkedOut;
		var $checkedOutTime;
		var $ordering;
		var $param;
		var $userId;
		var $catid;
		var $acces;
		
	}
?>