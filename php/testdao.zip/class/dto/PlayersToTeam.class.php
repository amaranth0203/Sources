<?php
	/**
	 * Object represents table 'players_to_teams'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class PlayersToTeam{
		
		var $teamId;
		var $playerId;
		var $name;
		
	}
?>