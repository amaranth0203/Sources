<?php
	/**
	 * Object represents table 'core_acl_groups_aro_map'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class CoreAclGroupsAroMap{
		
		var $groupId;
		var $sectionValue;
		var $aroId;
		
	}
?>