<?php
	/**
	 * Object represents table 'menu'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Menu{
		
		var $id;
		var $menutype;
		var $name;
		var $link;
		var $type;
		var $published;
		var $parent;
		var $componentid;
		var $sublevel;
		var $ordering;
		var $checkedOut;
		var $checkedOutTime;
		var $pollid;
		var $browserNav;
		var $acces;
		var $utacces;
		var $param;
		
	}
?>