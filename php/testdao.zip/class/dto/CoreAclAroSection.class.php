<?php
	/**
	 * Object represents table 'core_acl_aro_sections'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class CoreAclAroSection{
		
		var $sectionId;
		var $value;
		var $orderValue;
		var $name;
		var $hidden;
		
	}
?>