<?php
	/**
	 * Object represents table 'session'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Session{
		
		var $username;
		var $time;
		var $sessionId;
		var $guest;
		var $userid;
		var $usertype;
		var $gid;
		
	}
?>