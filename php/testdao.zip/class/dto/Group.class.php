<?php
	/**
	 * Object represents table 'groups'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Group{
		
		var $id;
		var $name;
		
	}
?>