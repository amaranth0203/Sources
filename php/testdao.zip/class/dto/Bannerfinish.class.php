<?php
	/**
	 * Object represents table 'bannerfinish'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Bannerfinish{
		
		var $bid;
		var $cid;
		var $type;
		var $name;
		var $impression;
		var $click;
		var $imageurl;
		var $datestart;
		var $dateend;
		
	}
?>