<?php
	/**
	 * Object represents table 'newsfeeds'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Newsfeed{
		
		var $catid;
		var $id;
		var $name;
		var $link;
		var $filename;
		var $published;
		var $numarticle;
		var $cacheTime;
		var $checkedOut;
		var $checkedOutTime;
		var $ordering;
		
	}
?>