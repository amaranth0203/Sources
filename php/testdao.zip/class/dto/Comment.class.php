<?php
	/**
	 * Object represents table 'comment'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Comment{
		
		var $id;
		var $articleid;
		var $ip;
		var $name;
		var $comment;
		var $startdate;
		var $published;
		
	}
?>