<?php
	/**
	 * Object represents table 'core_acl_aro'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class CoreAclAro{
		
		var $aroId;
		var $sectionValue;
		var $value;
		var $orderValue;
		var $name;
		var $hidden;
		
	}
?>