<?php
	/**
	 * Object represents table 'players_to_teams2'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-10-17 06:11	 
	 */
	class PlayersToTeams2{
		
		var $teamId;
		var $playerId;
		var $name;
		
	}
?>