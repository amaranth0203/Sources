<?php
	/**
	 * Object represents table 'anunciantes_cat'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class AnunciantesCat{
		
		var $codigo;
		var $codAnunciante;
		var $codCategoria;
		
	}
?>