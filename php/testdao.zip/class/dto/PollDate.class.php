<?php
	/**
	 * Object represents table 'poll_date'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class PollDate{
		
		var $id;
		var $date;
		var $voteId;
		var $pollId;
		
	}
?>