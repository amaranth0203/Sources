<?php
	/**
	 * Object represents table 'bannerclient'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Bannerclient{
		
		var $cid;
		var $name;
		var $contact;
		var $email;
		var $extrainfo;
		var $checkedOut;
		var $checkedOutTime;
		var $editor;
		
	}
?>