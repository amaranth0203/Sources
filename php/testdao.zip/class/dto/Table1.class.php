<?php
	/**
	 * Object represents table 'table1'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-10-17 02:54	 
	 */
	class Table1{
		
		var $idAuto;
		var $data1;
		
	}
?>