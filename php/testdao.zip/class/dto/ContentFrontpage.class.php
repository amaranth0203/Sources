<?php
	/**
	 * Object represents table 'content_frontpage'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class ContentFrontpage{
		
		var $contentId;
		var $ordering;
		
	}
?>