<?php
	/**
	 * Object represents table 'components'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Component{
		
		var $id;
		var $name;
		var $link;
		var $menuid;
		var $parent;
		var $adminMenuLink;
		var $adminMenuAlt;
		var $option;
		var $ordering;
		var $adminMenuImg;
		var $iscore;
		var $param;
		
	}
?>