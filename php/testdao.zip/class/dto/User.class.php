<?php
	/**
	 * Object represents table 'users'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class User{
		
		var $id;
		var $name;
		var $username;
		var $email;
		var $password;
		var $usertype;
		var $block;
		var $sendEmail;
		var $gid;
		var $registerDate;
		var $lastvisitDate;
		var $activation;
		var $param;
		
	}
?>