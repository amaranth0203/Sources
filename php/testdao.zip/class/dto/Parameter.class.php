<?php
	/**
	 * Object represents table 'parameters'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Parameter{
		
		var $id;
		var $paramName;
		var $paramFile;
		var $paramVersion;
		var $param;
		
	}
?>