<?php
	/**
	 * Object represents table 'messages_cfg'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class MessagesCfg{
		
		var $userId;
		var $cfgName;
		var $cfgValue;
		
	}
?>