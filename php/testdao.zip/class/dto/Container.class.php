<?php
	/**
	 * Object represents table 'containers'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Container{
		
		var $id;
		var $parentid;
		var $ordering;
		var $published;
		var $childcount;
		var $name;
		var $title;
		var $windowtitle;
		var $keyword;
		var $icon;
		var $description;
		
	}
?>