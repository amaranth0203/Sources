<?php
	/**
	 * Object represents table 'poll_data'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class PollData{
		
		var $id;
		var $pollid;
		var $text;
		var $hit;
		
	}
?>