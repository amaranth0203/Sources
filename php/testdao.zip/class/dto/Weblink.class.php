<?php
	/**
	 * Object represents table 'weblinks'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Weblink{
		
		var $id;
		var $catid;
		var $sid;
		var $title;
		var $url;
		var $description;
		var $date;
		var $hit;
		var $published;
		var $checkedOut;
		var $checkedOutTime;
		var $ordering;
		var $archived;
		var $approved;
		var $param;
		
	}
?>