<?php
	/**
	 * Object represents table 'modules_menu'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class ModulesMenu{
		
		var $moduleid;
		var $menuid;
		
	}
?>