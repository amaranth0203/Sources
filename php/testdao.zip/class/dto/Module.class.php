<?php
	/**
	 * Object represents table 'modules'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Module{
		
		var $id;
		var $title;
		var $content;
		var $ordering;
		var $position;
		var $checkedOut;
		var $checkedOutTime;
		var $published;
		var $module;
		var $numnew;
		var $acces;
		var $showtitle;
		var $param;
		var $iscore;
		var $clientId;
		
	}
?>