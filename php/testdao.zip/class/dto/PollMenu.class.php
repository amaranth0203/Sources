<?php
	/**
	 * Object represents table 'poll_menu'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class PollMenu{
		
		var $pollid;
		var $menuid;
		
	}
?>