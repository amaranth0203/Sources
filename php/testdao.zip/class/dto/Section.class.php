<?php
	/**
	 * Object represents table 'sections'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Section{
		
		var $id;
		var $title;
		var $name;
		var $image;
		var $scope;
		var $imagePosition;
		var $description;
		var $published;
		var $checkedOut;
		var $checkedOutTime;
		var $ordering;
		var $acces;
		var $count;
		var $param;
		
	}
?>