<?php
	/**
	 * Object represents table 'categories'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Categorie{
		
		var $id;
		var $parentId;
		var $title;
		var $name;
		var $image;
		var $section;
		var $imagePosition;
		var $description;
		var $published;
		var $checkedOut;
		var $checkedOutTime;
		var $editor;
		var $ordering;
		var $acces;
		var $count;
		var $param;
		
	}
?>