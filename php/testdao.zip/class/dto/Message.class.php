<?php
	/**
	 * Object represents table 'messages'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Message{
		
		var $messageId;
		var $userIdFrom;
		var $userIdTo;
		var $folderId;
		var $dateTime;
		var $state;
		var $priority;
		var $subject;
		var $message;
		
	}
?>