<?php
	/**
	 * Object represents table 'usertypes'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Usertype{
		
		var $id;
		var $name;
		var $mask;
		
	}
?>