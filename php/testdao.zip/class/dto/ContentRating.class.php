<?php
	/**
	 * Object represents table 'content_rating'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class ContentRating{
		
		var $contentId;
		var $ratingSum;
		var $ratingCount;
		var $lastip;
		
	}
?>