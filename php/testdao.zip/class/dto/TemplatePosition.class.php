<?php
	/**
	 * Object represents table 'template_positions'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class TemplatePosition{
		
		var $id;
		var $position;
		var $description;
		
	}
?>