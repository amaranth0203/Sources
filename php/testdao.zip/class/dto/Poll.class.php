<?php
	/**
	 * Object represents table 'polls'
	 *
     	 * @author: http://phpdao.com
     	 * @date: 2009-11-24 17:17	 
	 */
	class Poll{
		
		var $id;
		var $title;
		var $voter;
		var $checkedOut;
		var $checkedOutTime;
		var $published;
		var $acces;
		var $lag;
		
	}
?>