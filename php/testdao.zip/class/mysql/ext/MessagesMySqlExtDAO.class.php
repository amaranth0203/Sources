<?php
/*
 * Class that operate on table 'messages'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 03:43
 */
class MessagesMySqlExtDAO extends MessagesMySqlDAO{

	
}
?>