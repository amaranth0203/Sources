<?php
/*
 * Class that operate on table 'users'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 03:43
 */
class UsersMySqlExtDAO extends UsersMySqlDAO{

	
}
?>