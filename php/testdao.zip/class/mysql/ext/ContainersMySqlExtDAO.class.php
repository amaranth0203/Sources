<?php
/*
 * Class that operate on table 'containers'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 03:43
 */
class ContainersMySqlExtDAO extends ContainersMySqlDAO{

	
}
?>