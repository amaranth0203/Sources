<?php
/*
 * Class that operate on table 'players_to_teams'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 06:12
 */
class PlayersToTeamsMySqlExtDAO extends PlayersToTeamsMySqlDAO{

	
}
?>