<?php
/*
 * Class that operate on table 'messages_cfg'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 03:43
 */
class MessagesCfgMySqlExtDAO extends MessagesCfgMySqlDAO{

	
}
?>