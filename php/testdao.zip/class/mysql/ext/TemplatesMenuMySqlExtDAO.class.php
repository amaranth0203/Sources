<?php
/*
 * Class that operate on table 'templates_menu'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 03:43
 */
class TemplatesMenuMySqlExtDAO extends TemplatesMenuMySqlDAO{

	
}
?>