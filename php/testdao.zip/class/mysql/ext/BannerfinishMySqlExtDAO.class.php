<?php
/*
 * Class that operate on table 'bannerfinish'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 03:43
 */
class BannerfinishMySqlExtDAO extends BannerfinishMySqlDAO{

	
}
?>