<?php
/*
 * Class that operate on table 'core_acl_aro_groups'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 03:43
 */
class CoreAclAroGroupsMySqlExtDAO extends CoreAclAroGroupsMySqlDAO{

	
}
?>