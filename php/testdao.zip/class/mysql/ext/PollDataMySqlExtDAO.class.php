<?php
/*
 * Class that operate on table 'poll_data'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 03:43
 */
class PollDataMySqlExtDAO extends PollDataMySqlDAO{

	
}
?>