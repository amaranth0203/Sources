<?php
/*
 * Class that operate on table 'core_acl_aro'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 03:43
 */
class CoreAclAroMySqlExtDAO extends CoreAclAroMySqlDAO{

	
}
?>