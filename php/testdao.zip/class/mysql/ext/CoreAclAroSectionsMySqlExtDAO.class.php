<?php
/*
 * Class that operate on table 'core_acl_aro_sections'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 03:43
 */
class CoreAclAroSectionsMySqlExtDAO extends CoreAclAroSectionsMySqlDAO{

	
}
?>