<?php
/*
 * Class that operate on table 'anunciantes_cat'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-11-24 16:55
 */
class AnunciantesCatMySqlExtDAO extends AnunciantesCatMySqlDAO{

	
}
?>