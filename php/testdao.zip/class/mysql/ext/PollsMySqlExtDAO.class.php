<?php
/*
 * Class that operate on table 'polls'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 03:43
 */
class PollsMySqlExtDAO extends PollsMySqlDAO{

	
}
?>