<?php
/*
 * Class that operate on table 'core_acl_groups_aro_map'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 03:43
 */
class CoreAclGroupsAroMapMySqlExtDAO extends CoreAclGroupsAroMapMySqlDAO{

	
}
?>