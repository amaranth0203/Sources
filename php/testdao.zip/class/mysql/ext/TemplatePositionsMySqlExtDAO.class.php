<?php
/*
 * Class that operate on table 'template_positions'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 03:43
 */
class TemplatePositionsMySqlExtDAO extends TemplatePositionsMySqlDAO{

	
}
?>