<?php
/*
 * Class that operate on table 'parameters'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 03:43
 */
class ParametersMySqlExtDAO extends ParametersMySqlDAO{

	
}
?>