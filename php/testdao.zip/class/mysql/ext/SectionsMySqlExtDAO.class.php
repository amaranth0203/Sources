<?php
/*
 * Class that operate on table 'sections'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 03:43
 */
class SectionsMySqlExtDAO extends SectionsMySqlDAO{

	
}
?>