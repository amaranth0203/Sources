<?php
/*
 * Class that operate on table 'menu'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 03:43
 */
class MenuMySqlExtDAO extends MenuMySqlDAO{

	
}
?>