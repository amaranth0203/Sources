<?php
/*
 * Class that operate on table 'components'. Database Mysql.
 *
 * @author: http://phpdao.com
 * @date: 2009-10-17 03:43
 */
class ComponentsMySqlExtDAO extends ComponentsMySqlDAO{

	
}
?>