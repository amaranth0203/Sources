#include "HookD3D.h"
#include "filesystem.h"
using namespace Platform;

HMODULE g_D3D;		//d3d9.dll�ľ��

#define NAKED __declspec(naked)

typedef void (*D3D_VOID)(void);

D3D_VOID lpfnCheckFullscreen = NULL;
D3D_VOID lpfnD3DPERF_BeginEvent = NULL;
D3D_VOID lpfnD3DPERF_EndEvent = NULL;
D3D_VOID lpfnD3DPERF_GetStatus = NULL;
D3D_VOID lpfnD3DPERF_QueryRepeatFrame = NULL;
D3D_VOID lpfnD3DPERF_SetMarker = NULL;
D3D_VOID lpfnD3DPERF_SetOptions = NULL;
D3D_VOID lpfnD3DPERF_SetRegion = NULL;
D3D_VOID lpfnDebugSetLevel = NULL;
D3D_VOID lpfnDebugSetMute = NULL;
D3D_VOID lpfnDirect3DCreate9 = NULL;
D3D_VOID lpfnDirect3DShaderValidatorCreate9 = NULL;
D3D_VOID lpfnPSGPError = NULL;
D3D_VOID lpfnPSGPSampleTexture = NULL;

D3D_VOID lpfnDirect3DCreate92 = NULL;

void ReleaseD3D()
{
	if(g_D3D)
	{
		FreeLibrary(g_D3D);
	}
}

bool HookD3D()
{
	wstring sysD3D=GetSysDir();
	sysD3D+=L"\\d3d9.dll";
	wstring naotimerDLL=GetCurPath();
	naotimerDLL+=L"\\naotimer.dll";
	g_D3D=NULL;
	g_D3D = LoadLibrary(naotimerDLL.c_str());
	if (g_D3D == NULL)						//�Ҳ���Naotimer�����ʹ��Ĭ�ϵ�D3D9.dll
	{
		g_D3D = LoadLibrary(sysD3D.c_str());
			if (g_D3D == NULL)
			{
				MessageBox(NULL, _T("Ҫ������������Ϸ������Ҫ��װMicrosoft DirectX 9.0c����ǰ�������վ���ز���װDirectX9.0c"), _T("����-�Ҳ���DirectX9��������"), MB_OK);
				WriteLog("�Ҳ���DirectX9��������,Ҫ������������Ϸ������Ҫ��װMicrosoft DirectX 9.0c.\n");
				return FALSE;
			}
	}
	else
	{
		WriteLog("��ϵͳ�з���Naotimer�������������Naotimer����ع���.\n");
	}

	lpfnCheckFullscreen = (D3D_VOID)
		GetProcAddress(g_D3D, "CheckFullscreen");

	lpfnDirect3DShaderValidatorCreate9 = (D3D_VOID)
		GetProcAddress(g_D3D, "Direct3DShaderValidatorCreate9");

	lpfnPSGPError = (D3D_VOID)
		GetProcAddress(g_D3D, "PSGPError");

	lpfnPSGPSampleTexture = (D3D_VOID)
		GetProcAddress(g_D3D, "PSGPSampleTexture");

	lpfnD3DPERF_BeginEvent = (D3D_VOID)
		GetProcAddress(g_D3D, "D3DPERF_BeginEvent");

	lpfnD3DPERF_EndEvent = (D3D_VOID)
		GetProcAddress(g_D3D, "D3DPERF_EndEvent");

	lpfnD3DPERF_GetStatus = (D3D_VOID)
		GetProcAddress(g_D3D, "D3DPERF_GetStatus");

	lpfnD3DPERF_QueryRepeatFrame = (D3D_VOID)
		GetProcAddress(g_D3D, "D3DPERF_QueryRepeatFrame");

	lpfnD3DPERF_SetMarker = (D3D_VOID)
		GetProcAddress(g_D3D, "D3DPERF_SetMarker");

	lpfnD3DPERF_SetOptions = (D3D_VOID)
		GetProcAddress(g_D3D, "D3DPERF_SetOptions");

	lpfnD3DPERF_SetRegion = (D3D_VOID)
		GetProcAddress(g_D3D, "D3DPERF_SetRegion");

	lpfnDebugSetLevel = (D3D_VOID)
		GetProcAddress(g_D3D, "DebugSetLevel");

	lpfnDebugSetMute = (D3D_VOID)
		GetProcAddress(g_D3D, "DebugSetMute");

	lpfnDirect3DCreate9 = (D3D_VOID)
		GetProcAddress(g_D3D, "Direct3DCreate9");

	//MessageBox(NULL, _T("d3d9.dll�������"), _T("״̬"), MB_OK);
	return TRUE;
}


// ������ D3D9.DLL �� 14 ����������
NAKED void PSGPSampleTexture()
{
	__asm	jmp lpfnPSGPSampleTexture
}

NAKED void CheckFullscreen()
{
	__asm	jmp lpfnCheckFullscreen
}

NAKED void D3DPERF_BeginEvent()
{
	__asm	jmp lpfnD3DPERF_BeginEvent
}

NAKED void D3DPERF_EndEvent()
{
	__asm	jmp lpfnD3DPERF_EndEvent
}

NAKED void D3DPERF_SetMarker()
{
	__asm	jmp lpfnD3DPERF_SetMarker
}

NAKED void D3DPERF_SetRegion()
{
	__asm	jmp lpfnD3DPERF_SetRegion
}

NAKED void D3DPERF_QueryRepeatFrame()
{
	__asm	jmp lpfnD3DPERF_QueryRepeatFrame
}

NAKED void D3DPERF_SetOptions()
{
	__asm	jmp lpfnD3DPERF_SetOptions
}

NAKED void D3DPERF_GetStatus()
{
	__asm	jmp lpfnD3DPERF_GetStatus
}

void* WINAPI Direct3DCreate9(UINT SDKVersion)
{
	void* pIDirect3D9;
	_asm push SDKVersion;
	_asm call lpfnDirect3DCreate9;
	_asm mov pIDirect3D9,eax;

	return pIDirect3D9;
}

NAKED void DebugSetMute()
{
	__asm	jmp lpfnDebugSetMute
}

NAKED void DebugSetLevel()
{
	__asm	jmp lpfnDebugSetLevel
}

NAKED void Direct3DShaderValidatorCreate9()
{
	__asm	jmp lpfnDirect3DShaderValidatorCreate9
}

NAKED void PSGPError()
{
	
	__asm	jmp lpfnPSGPError
}
