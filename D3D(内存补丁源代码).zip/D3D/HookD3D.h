#pragma once
#include "main.h"

bool	HookD3D();		//Hook d3d9.dll
void	ReleaseD3D();
bool	LoadWS();
void	ReleaseWS();	