#include "Main.h"
#include "hookd3d.h"
#include "filesystem.h"
#include "patch\patch.h"
using namespace Platform;
//=====================================================================================================================================================
wstring	iniFile;
CPatch	Patch;
//=====================================================================================================================================================

//DLL���
BOOL APIENTRY DllMain( HANDLE hModule,DWORD ul_reason_for_call,LPVOID lpReserved)
{
	try
	{
		switch (ul_reason_for_call)
		{
		case DLL_PROCESS_ATTACH:
			{
				//DisableThreadLibraryCalls( (HMODULE)hModule );
				DeleteFile(L".\\d3d.log");
				WriteLog("Mabinogi�ڴ油����ʼ���ɹ�������׼����ع���.\n");
				iniFile=GetCurPath();
				iniFile+=L"\\d3d9.ini";
				if(!HookD3D())
				{
					MessageBox(0,L"HookD3D()����ʧ��\n",L"����",MB_OK);
					return(FALSE);
				}
				Patch.Install();				
				WriteLog("Mabinogi�ڴ油�������ɹ�.\n");
				break;
			}

		case DLL_THREAD_ATTACH:break;
		case DLL_THREAD_DETACH:break;
		case DLL_PROCESS_DETACH:
			{
				ReleaseD3D();
				WriteLog("Mabinogi�ڴ油��ж�����.\n");
				break;
			}
		}
		return TRUE;
	}
	catch(...)
	{
		WriteLog("Mabinogi�ڴ油����ʼ������������ϵ�����Ի�ü���֧��.");
	}
}

//��Ŀ���ļ���д������
void __cdecl WriteLog( const char* format, ... )
{
	va_list	valist;
	FILE *fp;

#if _MSC_VER >= 1400 // .NET2005
	if( fopen_s( &fp, ".\\d3d.log", "a" ) )
		return ;
#else
	fp = fopen( ".\\d3d.log", "a" );
	if( fp == NULL )
		return;
#endif

	char buf1[32],buf2[32];

#if _MSC_VER >= 1400 //.NET2005
	_strdate_s( buf1, 32 );
	_strtime_s( buf2, 32 );
#else
	_strdate( buf1 );
	_strtime( buf2 );
#endif

	fprintf( fp, "[%s %s] - ", buf1, buf2 );

	va_start( valist, format );
	vfprintf( fp, format, valist );
	va_end( valist );
	fclose(fp);

}

// ==========================================================================
// �� buffer �е� size ��С������д�����̵�ָ����ַ Address ��
// ==========================================================================
void WriteMem(LPVOID lpAddress, LPVOID lpBuffer, SIZE_T nSize)
{
	DWORD OldProtect, OldProtect2;
	VirtualProtect(lpAddress, nSize, PAGE_READWRITE, &OldProtect);
	memcpy(lpAddress, lpBuffer, nSize);
	VirtualProtect(lpAddress, nSize, OldProtect, &OldProtect2);
}

// ==========================================================================
// �� ���̵�ָ����ַ Address ���� size ��С������д��buffer��
// ==========================================================================
void ReadMem(LPVOID lpAddress, LPVOID lpBuffer, SIZE_T nSize)
{
	DWORD OldProtect, OldProtect2;
	VirtualProtect(lpAddress, nSize, PAGE_READWRITE, &OldProtect);
	memcpy(lpBuffer, lpAddress, nSize);
	VirtualProtect(lpAddress, nSize, OldProtect, &OldProtect2);
}