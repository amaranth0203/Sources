// lua.hpp
// Lua header files for C++
// <<extern "C">> not supplied automatically because Lua also compiles as C++
#ifdef _DEBUG
#pragma comment(lib, "luaD.lib")
#pragma comment(lib, "luaxD.lib")
#else
#pragma comment(lib, "lua.lib")
#pragma comment(lib, "luax.lib")
#endif

extern "C" {
#include "lua.h"
#include "lualib.h"
#include "lauxlib.h"
}
