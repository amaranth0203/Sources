#pragma once
//d3d9.dll��hook�汾��ʹ�ò�ͬ���Ӳ�����ʵ�ֶԲ�ͬ��Ϸ��Hook���ܡ�
//��������ʱ������hook Microsoft d3d9.dll����������к�����ԭ������

#include "windows.h"
#include <mmsystem.h>
#include <process.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include "wchar.h"
#include <tchar.h>
#include <basetsd.h>
#include <stdarg.h>

//STLͷ�ļ�
#include <iostream>
#include <vector>
#include <list>
#include <map>
#include <algorithm>
#include <iterator>
#include<stack>
#include <fstream>

#include <assert.h>

using namespace std;

//��������
#define null 0

//�궨��
#define SAFE_DELETE(p)  { if(p) { delete [] (p);     (p)=NULL; } }
#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }
#define	IF_FAIL_RTN(p)	{if(!(p)){return(0);}}
#define	RGB16(r,g,b)	{r<<11+g<<5+b}

//--------------------------------------------------------------------------------------
// �����Է����Ӵ�����
//--------------------------------------------------------------------------------------
#define SET_ACCESSOR( x, y )       inline void Set##y( x t )   { m_##y = t; };
#define GET_ACCESSOR( x, y )       inline x& Get##y()           { return m_##y; };
#define GET_SET_ACCESSOR( x, y )   SET_ACCESSOR( x, y ) GET_ACCESSOR( x, y )

#define SETP_ACCESSOR( x, y )      inline void Set##y( x* t )  { m_##y = *t; };
#define GETP_ACCESSOR( x, y )      inline x* Get##y()          { return &m_##y; };
#define GETP_SETP_ACCESSOR( x, y ) SETP_ACCESSOR( x, y ) GETP_ACCESSOR( x, y )
	

//�����������¶���
typedef unsigned short unichar;
typedef unsigned int uint;
typedef unsigned long ulong;
typedef double real;
typedef __int64  int64;
typedef wchar_t wchar;

void inline debug_print(string str)
{
	cout<<str.c_str()<<'\n';
}

wstring inline toString(int n)
{
	wstring t;
	wchar_t buff[32];
	_itow_s(n,buff,10);
	t=buff;
	return(t);
}
wstring inline toString(float n)
{
	wstring t;
	wchar_t buff[32];
	swprintf_s(buff,L"%f",n);
	t=buff;
	return(t);
}
wstring inline toString(ulong n)
{
	wstring t;
	wchar_t buff[32];
	_ultow_s(n,buff,10);
	t=buff;
	return(t);
}

wstring inline toString(string str)
{
	wstring t=L"";
	ulong i;
	for(i=0;i<str.length();++i)
	{
		t+=(unichar)(str.c_str()[i]);
	}
	return(t);
}

//��UTF-8�ַ���ת��ΪUnicode
wstring inline UTF8toString(string utf)
{
	wchar_t *buff=new wchar_t[utf.length()+1];
	int i=MultiByteToWideChar(CP_UTF8, 0, utf.c_str(),-1, buff, (int)utf.length());
	buff[i+1]=0;
	wstring str=buff;
	delete [] buff;
	return(str);
}
//��Unicode�ַ���ת��ΪUTF-8
string	inline toUTF8(wstring str)
{
	char* buff;
	int buffersize=WideCharToMultiByte(CP_UTF8,0,str.c_str(),(int)str.length(),0,0,0,0);		//��ȡ��Ҫ���������������
	buff=new char[buffersize+1];
	WideCharToMultiByte(CP_UTF8,0,str.c_str(),(int)str.length(),buff,buffersize+1,0,0);
	buff[buffersize]=0;
	string utf=buff;
	delete []buff;
	return(utf);
}

string	inline toAnsiString(wstring str)
{
	string t="";
	ulong i;
	for(i=0;i<str.length();++i)
	{
		t+=(char)(str.c_str()[i]);
	}
	return(t);
}

inline DWORD FtoDW( FLOAT f){return *((DWORD*)&f);}

float inline sqr(float x)
{
	return(x*x);
}

//==================================================================================================================================
void __cdecl WriteLog( const char* format, ... );
void WriteMem(LPVOID lpAddress, LPVOID lpBuffer, SIZE_T nSize);
void ReadMem(LPVOID lpAddress, LPVOID lpBuffer, SIZE_T nSize);