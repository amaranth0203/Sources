#include "patch.h"

//��Ҫ�޸ĵĵط�λ�ھ���Pleione::Startup() 0x1262C9��,�������Ϊ:
//CMP eax,2
//JNZ 63928190
BOOL CPatch::ShowItemPrice(void)
{
	UINT fgPatchOn = GetPrivateProfileInt(_T("PATCH"), _T("ShowItemPrice"), 0, iniFile.c_str());
	if (!fgPatchOn)
	{
		DebugPrint(("ShowItemPrice = 0"));
		return FALSE;
	}
	DebugPrint(("ShowItemPrice = 1"));

	try
	{
		MEMORY_BASIC_INFORMATION mbiPleione;
		HMODULE hPleione = GetModuleHandle(_T("pleione.dll"));
		DWORD address, counter;
		VirtualQuery((LPCVOID)(hPleione+0x1000), &mbiPleione, sizeof(MEMORY_BASIC_INFORMATION));

		// �Ҳ�����Ч�Ĳ����㷨��ֱ�����û�����
		__asm
		{
			pushad
			mov counter, 0
			mov edi, mbiPleione.BaseAddress
			mov ecx, mbiPleione.RegionSize
			cld
			mov al, 83h
		jmp_repeat:
			repnz scas byte ptr es:[edi]
			jnz jmp_exit
			cmp byte ptr ds:[edi], 0F8h
			jnz jmp_repeat
			cmp byte ptr ds:[edi+1], 02h
			jnz jmp_repeat
			cmp byte ptr ds:[edi+2], 0Fh
			jnz jmp_repeat
			cmp byte ptr ds:[edi+3], 85h
			jnz jmp_repeat
			cmp byte ptr ds:[edi+4], 86h
			jnz jmp_repeat
			cmp byte ptr ds:[edi+5], 01h
			jnz jmp_repeat
			cmp byte ptr ds:[edi+6], 00h
			jnz jmp_repeat
			cmp byte ptr ds:[edi+7], 00h
			jnz jmp_repeat
			// �ҵ���
			inc counter
			dec edi
			mov address, edi
			inc edi
			jmp jmp_repeat
		jmp_exit:
			popad
		}

		if (counter == 1)
		{
			static UCHAR Patch[] = {0x83, 0xF8, 0x02, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90};
			WriteMem((LPVOID)address, Patch, sizeof(Patch));
		}
		else if (counter == 0)
		{
			DebugPrint(("CPatch::ShowItemPrice() û���ҵ������ַ���"));
			return FALSE;
		}
		else
		{
			DebugPrint(("CPatch::ShowItemPrice() �ҵ���������ַ���"));
			return FALSE;
		}
	}
	catch(...)
	{
		DebugPrint(("CPatch::ShowItemPrice() �����쳣"));
		return FALSE;
	}

	WriteLog("��Ʒ�۸���ʾ�������ӳɹ�.\n");
	return TRUE;
}
