#include "patch.h"

static CHAR pszSetFog[] =		// standard.dll
	"?SetFog@CDungeonRegion@core@@QAEX_N@Z";
static CHAR pszSetFog2[] =		// standard.dll
	"?SetFog@CDungeonRegion@core@@QAEX_N@Z";

BOOL CPatch::DungeonMiniMapNofog(void)
{
	UINT fgPatchOn = GetPrivateProfileInt(_T("PATCH"), _T("DungeonMiniMapNofog"), 0, iniFile.c_str());
	if (!fgPatchOn)
	{
		return FALSE;
	}

	try
	{
		LPBYTE lpbuf = (LPBYTE)GetProcAddress( GetModuleHandle(_T("standard.dll")),
												pszSetFog );

		if (*(LPDWORD)(lpbuf + 0x02) != 0x04244C8a)
		{
			WriteLog("CPatch::DungeonMiniMapNofog(): �ؼ��ֲ�ƥ��\n");
			return FALSE;
		}
		else
		{
			BYTE Code[] = { 0x32, 0xC9, 0x90, 0x90 };
			WriteMem(lpbuf + 0x02, Code, sizeof(Code));

			//BYTE Code2[]={0xB0,0x00,0xC3};
			//WriteMem(lpbuf -0xED0A4, Code2, sizeof(Code));

		}
	}
	catch(...)
	{
		WriteLog("CPatch::DungeonMiniMapNofog() �����쳣\n");
		return FALSE;
	}

	WriteLog("���³�������ͼ��ʾ��ʽ����ɹ�.\n");
	return TRUE;
}

