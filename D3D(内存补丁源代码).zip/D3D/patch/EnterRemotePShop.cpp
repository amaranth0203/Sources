#include "patch.h"

/*
����CPleion����Startup()�ľ���Ϊ0x3B931
$+103    >|.  D95D F0                   fstp    dword ptr [ebp-10]
$+106    >|.  D905 7835B563             fld     dword ptr [63B53578]
$+10C    >|.  D85D F0                   fcomp   dword ptr [ebp-10]
$+10F    >|.  DFE0                      fstsw   ax
$+111    >|.  F6C4 01                   test    ah, 1
$+114    >|.  75 15                     jnz     short 6383D794
$+116    >|.  FF75 14                   push    dword ptr [ebp+14]
$+119    >|.  8BCE                      mov     ecx, esi
$+11B    >|.  FF75 10                   push    dword ptr [ebp+10]
$+11E    >|.  FF75 0C                   push    dword ptr [ebp+C]
$+121    >|.  FF75 08                   push    dword ptr [ebp+8]
*/

static CHAR pszPleioneStartup[] =	// pleione.dll
	"?StartUp@CPleione@pleione@@QAE_NPAUHINSTANCE__@@0ABV?$CStringT@_WVunicode_string_trait@esl@@Vunicode_string_implement@2@@esl@@11_N2@Z";

BOOL CPatch::EnterRemotePShop()
{
	try
	{

		UINT fgPatchOn = GetPrivateProfileInt(_T("PATCH"), _T("EnterRemoteShop"), 0, iniFile.c_str());
		if (fgPatchOn==0)
		{
			DebugPrint(("EnterRemoteShop = 0"));
			return FALSE;
		}

		LPBYTE lpbuf = (LPBYTE)GetProcAddress( GetModuleHandle(_T("pleione.dll")),
												pszPleioneStartup );
		lpbuf+=0x3B931;
		if((DWORD)lpbuf==0x3B931)
		{
			DebugPrint("CPatch::EnterRemotePShop(): ��ȡĿ�꺯����ַʧ��.");
			return FALSE;
		}

		if ((*(LPWORD)(lpbuf + 0x103)  != 0x5DD9) ||	//fstp    dword ptr [ebp-10]
			(*(LPWORD)(lpbuf + 0x10F)  != 0xE0DF) ||	//fstsw   ax
			(*(LPWORD)(lpbuf + 0x114)  != 0x1575))		//jnz     short 6383D794
		{
			DebugPrint("CPatch::EnterRemotePShop(): �ؼ��ֲ�ƥ��.");
			return FALSE;
		}
		else
		{
			byte code[] = {0x90, 0x90};
			WriteMem((LPVOID)(lpbuf + 0x114), code, sizeof(code));
			WriteLog("�����̵�Զ������ʹ��ܿ�����\n");
			return TRUE;
		}
	}
	catch(...)
	{
		WriteLog("CPatch::EnterRemotePShop() �����쳣");
		return FALSE;
	}	
}
