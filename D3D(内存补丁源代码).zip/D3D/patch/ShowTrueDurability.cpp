#include "patch.h"

#define NAKED	__declspec(naked)

static CHAR pszPleioneStartup[] =	// pleione.dll
	"?StartUp@CPleione@pleione@@QAE_NPAUHINSTANCE__@@0ABV?$CStringT@_WVunicode_string_trait@esl@@Vunicode_string_implement@2@@esl@@11_N2@Z";

static float RedDuarbility = 999.0;

void GetDurability(void);
void GetDurabilityMax(void);

static LPVOID lpfnGetDurability = &GetDurability;
static LPVOID lpfnGetDurabilityMax = &GetDurabilityMax;

BOOL CPatch::ShowTrueDuarbility(void)
{

	UINT fgPatchOn = GetPrivateProfileInt(_T("PATCH"), _T("ShowTrueDuarbility"), 0, iniFile.c_str());
	if (!fgPatchOn)
	{
		DebugPrint("ShowTrueDuarbility = 0");
		return FALSE;
	}
	DebugPrint("ShowTrueDuarbility = 1");


	try
	{
		LPBYTE lpbuf = (LPBYTE)GetProcAddress( GetModuleHandle(_T("pleione.dll")),
												pszPleioneStartup );
		LPBYTE lpbuf2 = NULL;
		lpbuf+=0x1C34D2;
		if((DWORD)lpbuf==0x1C34D2)
		{
			DebugPrint("CPatch::ShowTrueDuarbility(): ��ȡĿ�꺯����ַʧ��.");
			return FALSE;
		}
		if  (*(lpbuf + 0x173) == 0xE8)
		{
			lpbuf2 = (lpbuf + 0x173) + (*(LPDWORD)(lpbuf + 0x174)) + 5;
		}
		else
		{
			DebugPrint("CPatch::ShowTrueDuarbility(): lpbuf2 ��ַδȡ��.");
			return FALSE;
		}

		if ((*(LPWORD)(lpbuf2 + 0x3B)  != 0x1D8B) ||	// mov edi, GetInterfaceDurability
			(*(LPWORD)(lpbuf2 + 0x7A)  != 0x15FF) ||	// call GetInterfaceDurabilityMax
			(*(LPWORD)(lpbuf2 + 0x179) != 0xF883) ||	// cmp eax, 0ah
			(*(LPWORD)(lpbuf2 + 0x17C) != 0x870F) ||	// ja $+9d
			(*(LPWORD)(lpbuf2 + 0x184) != 0x15FF) ||	// call GetInterfaceDurabilityMax
			(*(LPWORD)(lpbuf2 + 0x1A0) != 0x05DC))		// fadd (0.99)
		{
			DebugPrint("CPatch::ShowTrueDuarbility(): �ؼ��ֲ�ƥ��.");
			return FALSE;
		}
		else
		{
			DWORD CallAddr;
			CallAddr = (DWORD_PTR)(&lpfnGetDurability);
			WriteMem(lpbuf2 + 0x3D, &CallAddr, sizeof(CallAddr));
			CallAddr = (DWORD_PTR)(&lpfnGetDurabilityMax);
			WriteMem(lpbuf2 + 0x7C, &CallAddr, sizeof(CallAddr));
			WriteMem(lpbuf2 + 0x186, &CallAddr, sizeof(CallAddr));

			BYTE NopCode[] = {0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90};
			WriteMem(lpbuf2 + 0x179, NopCode, sizeof(NopCode));

			DWORD RedDuarbilityAddr = (DWORD_PTR)(&RedDuarbility);
			WriteMem(lpbuf2 + 0x1A2, &RedDuarbilityAddr, sizeof(RedDuarbilityAddr));
		}
	}
	catch(...)
	{
		DebugPrint("CPatch::ShowTrueDuarbility() �����쳣");
		return FALSE;
	}

	WriteLog("��Ʒ�;���ʾ��ʽ����ɹ�.\n");
	return TRUE;
}

NAKED static void GetDurability(void)
{
	__asm
	{
		MOV		EAX, DWORD PTR DS:[ECX+44h]
		RETN
	}
}

NAKED static void GetDurabilityMax(void)
{
	__asm
	{
		MOV		EAX, DWORD PTR DS:[ECX+48h]
		RETN
	}
}
