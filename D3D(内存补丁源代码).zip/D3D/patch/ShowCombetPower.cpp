#include "patch.h"

#define NAKED	__declspec(naked)


static CHAR pszGetDetailDisplayName[] =	// pleione.dll
	"?StartUp@CPleione@pleione@@QAE_NPAUHINSTANCE__@@0ABV?$CStringT@_WVunicode_string_trait@esl@@Vunicode_string_implement@2@@esl@@11_N2@Z";
static CHAR pszCTimeVarMgr[] =			// esl.dll
	"??0CTimeVarMgr@esl@@AAE@XZ";
static CHAR pszCStringEqu[] =			// ESL.dll
			"??4?$CStringT@_WVunicode_string_trait@esl@@Vunicode_string_implement@2@@esl@@QAEAAV01@PB_W@Z";
static CHAR pszGetCombatPower[] =		// Standard.dll
	"?GetCombatPower@IParameterBase2@core@@QBEMXZ";
static CHAR pszswprintf[] =				// MSVCR71.dll
	"swprintf";

static TCHAR pszFormat[] = _T("%.2f %s");
static TCHAR pszBuf[256];

static wchar pszBoss[]=L"�������(Boss) ";
static wchar pszAwful[]=L"���µ�(Awful) ";
static wchar pszStrong[]=L"ǿ���(Strong) ";
static wchar pszWeak[]=L"��С��(Weak) ";
static wchar pszWeakest[]=L"������(Weakest) ";

static LPVOID lpfnCTimeVarMgr = NULL;
static LPVOID lpfnGetCombatPower = NULL;
static LPVOID lpfnCStringEqu = NULL;
static LPVOID lpfnswprintf = NULL;
static LPVOID lpRet = NULL;

void Jump1(void);
void Jump2(void);
static BOOL init(void);


BOOL CPatch::ShowCombetPower(void)
{

	bool EnToSC=false;

	UINT fgPatchOn = GetPrivateProfileInt(_T("PATCH"), _T("ShowCombetPower"), 0, iniFile.c_str());
	if (!fgPatchOn)
	{
		DebugPrint(("ShowCombetPower = 0"));
		return FALSE;
	}
	DebugPrint(("ShowCombetPower = 1"));

	EnToSC = GetPrivateProfileInt(_T("PATCH"), _T("ShowChineseCombetScript"), 0, iniFile.c_str());

	if (!init())
	{
		DebugPrint(("CPatch::ShowCombetPower(): init() ����"));
		return FALSE;
	}

	try
	{
		LPBYTE lpbuf = (LPBYTE)GetProcAddress( GetModuleHandle(_T("pleione.dll")),
											   pszGetDetailDisplayName );
		LPBYTE lpbuf2 = lpbuf+0xE66AA;
		lpbuf+=0x1C65B1;
		// У�� 4�� PATCH���Ƿ�һ��
		if ((*(LPWORD)(lpbuf + 0x1A) != 0x840F) ||		// JE xxxxxxxx
			(*(LPWORD)(lpbuf + 0x2A) != 0x850F) ||		// JNZ xxxxxxxx
			(*(LPWORD)(lpbuf + 0x3C) != 0x850F) ||		// JNZ xxxxxxxx
			(*(LPWORD)(lpbuf + 0x7C) != 0x2A75) ||		// JNZ $+2CH
			(*(LPWORD)(lpbuf + 0x9F) != 0x4D8D) ||		// LEA ECX, [EBP-10]
			(*(LPWORD)(lpbuf + 0xA8) != 0x016A))		// PUSH 1 (lpRet)
		{
			DebugPrint(("CPatch::ShowCombetPower(): �ؼ��ֲ�ƥ��"));
			return FALSE;
		}
		else
		{
			DWORD JumpOffset;

			JumpOffset = (LPBYTE)Jump1 - (lpbuf + 0x1A) - 6;
			WriteMem(lpbuf + 0x1C, &JumpOffset, sizeof(JumpOffset));

			JumpOffset = (LPBYTE)Jump1 - (lpbuf + 0x2A) - 6;
			WriteMem(lpbuf + 0x2C, &JumpOffset, sizeof(JumpOffset));

			JumpOffset = (LPBYTE)Jump1 - (lpbuf + 0x3C) - 6;
			WriteMem(lpbuf + 0x3E, &JumpOffset, sizeof(JumpOffset));

			//ֱ�Ӵӵ�����SetCharaXXXBox���ֽ�����⣬���ж��Ƿ�����ҽ�ɫ�ĺ�������֮�����תȡ����
			//����IsNPC�ж�֮���je XXXXXȡ����
			//----------------------------------------------------------
			BYTE JC[]={0x90,0x90};
			if((*(LPWORD)(lpbuf2 + 0x6F) == 0x1A74))
			{
				WriteMem(lpbuf2 + 0x6F, JC, sizeof(JC));
			}
			//----------------------------------------------------------

			BYTE  JumpOffset2 = 0x3C - 0x7C - 2;
			WriteMem(lpbuf + 0x7D, &JumpOffset2, sizeof(JumpOffset2));

			BYTE JmpCode[] = {0xE9, 0, 0, 0, 0, 0x90, 0x90, 0x90, 0x90};
			*(LPDWORD)(JmpCode + 1) = (LPBYTE)Jump2 - (lpbuf + 0x9F) - 5;
			WriteMem(lpbuf + 0x9F, JmpCode, sizeof(JmpCode));

			lpRet = lpbuf + 0xA8;

			if(EnToSC==1)
			{
				BYTE Push_Code[5]={0x68,0x00,0x00,0x00,0x00};
				*(LPDWORD)(Push_Code + 1)=(DWORD)(wchar*)pszBoss;
				WriteMem(lpbuf + 0x7E, Push_Code, sizeof(Push_Code));
				*(LPDWORD)(Push_Code + 1)=(DWORD)(wchar*)pszAwful;
				WriteMem(lpbuf + 0x85, Push_Code, sizeof(Push_Code));
				*(LPDWORD)(Push_Code + 1)=(DWORD)(wchar*)pszStrong;
				WriteMem(lpbuf + 0x8c, Push_Code, sizeof(Push_Code));
				*(LPDWORD)(Push_Code + 1)=(DWORD)(wchar*)pszWeak;
				WriteMem(lpbuf + 0x93, Push_Code, sizeof(Push_Code));
				*(LPDWORD)(Push_Code + 1)=(DWORD)(wchar*)pszWeakest;
				WriteMem(lpbuf + 0x9A, Push_Code, sizeof(Push_Code));
				WriteLog("ս�����ȼ���ʾ��ʽ�������.\n");
			}
		}
	}
	catch(...)
	{
		DebugPrint(("CPatch::ShowCombetPower() �����쳣"));
		return FALSE;
	}

	WriteLog("����ս������ʾ�������ӳɹ�.\n");
	return TRUE;
}

static void FloattoString(wchar_t * buff,double f,wchar_t* str)
{
	swprintf_s(buff,255,L"%.2f %s ",f,str);
}

static BOOL init(void)
{
	__try
	{
		lpfnCTimeVarMgr = (LPVOID)GetProcAddress( GetModuleHandle(_T("esl.dll")),
												  pszCTimeVarMgr );
		if(!lpfnCTimeVarMgr) WriteLog("lpfnCTimeVarMgr\n");

		lpfnCStringEqu  = (LPVOID)GetProcAddress( GetModuleHandle(_T("esl.dll")),
												  pszCStringEqu );
		if(!lpfnCStringEqu) WriteLog("lpfnCStringEqu\n");

		lpfnGetCombatPower = (LPVOID)GetProcAddress( GetModuleHandle(_T("Standard.dll")),
													 pszGetCombatPower );
		if(!lpfnGetCombatPower) WriteLog("lpfnGetCombatPower\n");

		//lpfnswprintf = (LPVOID)GetProcAddress( GetModuleHandle(_T("MSVCR71.dll")),
		//									   pszswprintf );
		lpfnswprintf=(LPVOID)FloattoString;
		if(!lpfnswprintf) WriteLog("lpfnswprintf\n");
	}
	__except(1)
	{
		return FALSE;
	}

	if (lpfnCTimeVarMgr && 
		lpfnCStringEqu && 
		lpfnGetCombatPower && 
		lpfnswprintf)
	{
		return TRUE;
	}
	else
		return FALSE;
}



// ==========================================================================
static TCHAR pszStrNull[] = _T("");
NAKED static void Jump1(void)
{
	__asm
	{
		LEA		ECX, DWORD PTR SS:[EBP-10h]
		CALL	lpfnCTimeVarMgr
		AND     DWORD PTR SS:[EBP-4h], 0

		PUSH	offset pszStrNull
		JMP     Jump2
	}
}


NAKED static void Jump2(void)
{
	__asm
	{
		MOV		ECX, ESI
		MOV		EAX, DWORD PTR DS:[ECX]
		CALL	DWORD PTR DS:[EAX+4Ch]
		MOV		ECX, EAX
		CALL	lpfnGetCombatPower

		SUB		ESP, 8h
		FSTP	QWORD PTR SS:[ESP]
		//PUSH	offset pszFormat
		PUSH	offset pszBuf		
		CALL	lpfnswprintf
		ADD     ESP, 10h

		PUSH	offset pszBuf
		LEA		ECX, DWORD PTR SS:[EBP-10h]
		CALL	lpfnCStringEqu

		JMP		lpRet;
	}
}

