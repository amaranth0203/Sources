#pragma once

#include "..\main.h"

#define _SPECIAL_PATCH_FILECHECK_
#define _SPECIAL_PATCH2_NOFOG_
extern wstring iniFile;

union AD
{
	ulong addr;
	char c[4];
};

class CPatch
{
public:
	CPatch(void);
	~CPatch(void);
	BOOL Install(void);

private:
	// ����
	BOOL ShowCombetPower(void);
	BOOL ShowItemPrice(void);
	BOOL CharParam1000(void);
	BOOL DigitalFoodQuality(void);
	BOOL ShowTrueDuarbility(void);
	BOOL FixedNightLum(void);
	BOOL EnterRemotePShop(void);
	BOOL ModifyZoomWideLimit(void);
	BOOL ShowEnchantScrollExpiredTime(void);
	BOOL DungeonMiniMapNofog(void);
	BOOL NoEndAD(void);
	BOOL EnableFSAA();
};

void DebugPrint(string s);