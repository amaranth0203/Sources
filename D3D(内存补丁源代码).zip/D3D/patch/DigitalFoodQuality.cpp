#include "patch.h"

#define NAKED	__declspec(naked)

//Startup+0x2318E6

static CHAR pszPleioneStartup[] =	// pleione.dll
	"?StartUp@CPleione@pleione@@QAE_NPAUHINSTANCE__@@0ABV?$CStringT@_WVunicode_string_trait@esl@@Vunicode_string_implement@2@@esl@@11_N2@Z";
static CHAR pszCStringAdd[] =			// ESL.dll
	"??Y?$CStringT@_WVunicode_string_trait@esl@@Vunicode_string_implement@2@@esl@@QAEAAV01@PB_W@Z";
static LPVOID lpfnCStringAdd = NULL;
static LPVOID lpfnswprintf = NULL;
static LPVOID lpRet = NULL;


void Jump1(void);
static BOOL init(void);


BOOL CPatch::DigitalFoodQuality(void)
{
	UINT fgPatchOn = GetPrivateProfileInt(_T("PATCH"), _T("DigitalFoodQuality"), 0, iniFile.c_str());
	if (!fgPatchOn)
	{
		return FALSE;
	}

	if (!init())
	{
		return FALSE;
	}

	try
	{
		LPBYTE lpbuf = (LPBYTE)GetProcAddress( GetModuleHandle(_T("pleione.dll")),
											   pszPleioneStartup );
		lpbuf+=0x2318E6;
		if((DWORD)lpbuf==0x2318E6)
		{
			WriteLog("CPatch::DigitalFoodQuality()::��ȡ��λ��Ϣʧ��.\n");
			return(FALSE);
		}
		// У�� 4�� PATCH���Ƿ�һ��
		if ((*(LPWORD)(lpbuf + 0xCC) != 0xCB8B) ||		//	mov	ecx,ebx;
			(*(LPWORD)(lpbuf + 0xD4) != 0x7D80))		//	cmp byte ptr[ebp+18],0
		{
			WriteLog("ʳ����ʵƷ����ʾ���޷���ʼ�����������Ԥ�ڲ�����\n");
			return FALSE;
		}
		else
		{
			BYTE JmpCode[] = {0xE9, 0, 0, 0, 0, 0x90, 0x90, 0x90};
			*(LPDWORD)(JmpCode + 1) = (LPBYTE)Jump1 - (lpbuf + 0xCC) - 5;
			WriteMem(lpbuf + 0xCC, JmpCode, sizeof(JmpCode));

			lpRet = lpbuf + 0xD4;
		}
		WriteLog("����Ʒ�����ֻ���ʾ�������ӳɹ�.\n");
		return TRUE;
	}
	catch(...)
	{
		WriteLog("CPatch::DigitalFoodQuality() �����쳣.\n");
		return FALSE;
	}
}

static void FloattoString(wchar_t * buff,wchar_t* str,int d)
{
	swprintf_s(buff,255,L"%s (%d)",str,d);
}

static BOOL init(void)
{
	try
	{
		lpfnCStringAdd  = (LPVOID)GetProcAddress( GetModuleHandle(_T("esl.dll")),
												  pszCStringAdd );
		if(lpfnCStringAdd==NULL)
		{
			DebugPrint("lpfnCStringAdd==NULL");
		}
		lpfnswprintf = FloattoString;
	}
	catch(...)
	{
		return FALSE;
	}

	if ( lpfnCStringAdd && lpfnswprintf )
	{
		return TRUE;
	}
	else
		return FALSE;
}


static TCHAR pszFormat[] = _T("%s ( %d )");
static TCHAR pszBuf[256];
NAKED static void Jump1(void)
{
	//EAX:����Ʒ������
	//EBX:�ַ���ָ��
	//ECX:��
	__asm
	{
		pop		ecx				
		push	eax				; ����
		push	ecx				; ͼ���ַ���
		push	offset pszBuf
		call	lpfnswprintf
		add		esp, 0Ch

		push	offset pszBuf
		mov		ecx, ebx;
		call	lpfnCStringAdd

		jmp		lpRet
	}
}
